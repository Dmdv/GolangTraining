This example tries to reach non existing resource

To generate mocks, run following command:
mockgen -source=external_service/external_service.go -destination=mocks/mock_external_service.go -package=mocks