package external_service_test

import (
	"example.com/external_service/external_service"
	"example.com/external_service/mocks"
	"github.com/golang/mock/gomock"
	. "github.com/onsi/ginkgo"
	"github.com/onsi/gomega"
)

var _ = Describe("ExternalService", func() {

	var (
		ctrl *gomock.Controller
		mockExtSvc *mocks.MockExternalService
		search *external_service.YaSearch
	)

	BeforeEach(func() {
		ctrl = gomock.NewController(GinkgoT())
		mockExtSvc = mocks.NewMockExternalService(ctrl)
		search = &external_service.YaSearch{Service:mockExtSvc}

	})

	AfterEach(func() {
		ctrl.Finish()
	})

	Describe("YaSearch", func() {

		It("should return PageNotFound string if non existing html page requested", func() {

			mockExtSvc.EXPECT().ReadPage("http://www.ya555.com").Return("PageNotFound")

			res := search.Get("http://www.ya555.com")

			gomega.Expect(res).To(gomega.Equal("PageNotFound"))
		})
	})
})
