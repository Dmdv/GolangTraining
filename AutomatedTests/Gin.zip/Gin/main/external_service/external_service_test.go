package external_service

import (
	"example.com/external_service/mocks"
	"github.com/golang/mock/gomock"
	"testing"
)

func TestNotFound (t *testing.T) {
	mockCtrl := gomock.NewController(t)
	defer mockCtrl.Finish()

	mockExtSvc := mocks.NewMockExternalService(mockCtrl)

	search := &YaSearch{Service:mockExtSvc}

	mockExtSvc.EXPECT().ReadPage("http://www.ya555.com").Return("PageNotFound")

	search.Get("http://www.ya555.com")
}